GitHub Anypoint™ Studio Connector Demo
======================================

Want to contribute to this demo? Go to [Contributing to Anypoint Community Connectors](http://mulesoft.github.io/connector-certification-docs/contr/index.html) and get started!